<!--
============================================================
 Bot Reaction Free
 حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 Copyright © 2026 iaf1 — All rights reserved.
============================================================

[AR] إشعار المشروع:
 - هذا المشروع مجاني بالكامل.
 - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.

[AR] إخلاء المسؤولية:
 هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.

[EN] Project Notice:
 - This project is completely free.
 - This project is NOT for sale. Selling it, its source code, or any
   modified version of it is not permitted by the owner.
 - This copyright notice must be retained in all copies and derivatives.
 - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.

[EN] Disclaimer:
 This file is provided "AS IS", without warranty of any kind. The owner
 (iaf1) is not liable for any damage, loss, server issues, data loss,
 security issues, or misuse resulting from the use, modification, or
 hosting of this code. The user is solely responsible for its use.

Contact / للتواصل:
 Discord: iaf0
 GitHub:  https://github.com/iiaf1
-->

# Bot Reaction Free

بوت ديسكورد **مجاني ومفتوح المصدر** مبني بـ Node.js و discord.js. يضيف إيموجي تلقائيًا على **كل رسالة جديدة** في الرومات التي تحددها، ولكل روم إعداد مستقل.

## المميزات

- أوامر Slash عربية بالكامل، وللإدارة فقط (صلاحية `Administrator`).
- إيموجي عادي (🔥) وإيموجي مخصص (Custom Emoji) سواء ثابت أو متحرك.
- دعم عدة رومات، وكل روم له إيموجي وحالة (تشغيل/إيقاف) مستقلة.
- حفظ الإعدادات في SQLite، فلا تضيع بعد إعادة التشغيل.
- تجاهل رسائل البوتات والويبهوكات ورسائل النظام.
- طابور تفاعلات لكل روم مع معالجة أخطاء Discord وRate Limits دون توقف البوت.
- إعادة اتصال تلقائية عند انقطاع Discord، مع مراقب (Watchdog) يعيد تشغيل البوت إذا تعذر الاتصال طويلًا.
- سجلات (Logs) يومية للأحداث والأخطاء مع حذف تلقائي للقديم.
- تشغيل 24/7 عبر PM2.
- أقل صلاحيات ممكنة: **لا يحتاج أي Privileged Intent** ولا صلاحية إرسال رسائل.
- أوامر خاصة بمالك البوت (`OWNER_ID`).

## المتطلبات

- Node.js **20 أو أحدث**
- npm
- حساب Discord وتطبيق بوت من [Developer Portal](https://discord.com/developers/applications)

> المشروع يستخدم `better-sqlite3`. في أغلب الأنظمة يتثبت جاهزًا. إذا فشل التثبيت على Linux ثبّت أدوات البناء:
> `sudo apt install -y build-essential python3`

## 1) إنشاء البوت

1. افتح Developer Portal ← **New Application**.
2. من تبويب **Bot** اضغط **Reset Token** وانسخ التوكن (لا تشاركه مع أحد).
3. في **Privileged Gateway Intents** اترك الخيارات الثلاثة **مغلقة**. البوت لا يحتاجها.

## 2) معرفة OWNER_ID

فعّل **Developer Mode** من إعدادات Discord ← Advanced، ثم كليك يمين على حسابك ← **Copy User ID**.

## 3) التثبيت

```bash
git clone https://github.com/<your-username>/bot-reaction-free.git
cd bot-reaction-free
npm install
cp .env.example .env
```

عدّل ملف `.env` ليحتوي على متغيرين فقط:

```env
DISCORD_TOKEN=ضع_توكن_البوت_هنا
OWNER_ID=ضع_ايدي_الأونر_هنا
```

لا حاجة إلى `CLIENT_ID` ولا `GUILD_ID`: البوت يأخذ معرّف التطبيق تلقائيًا بعد تسجيل الدخول ويسجل الأوامر بشكل عام (Global).

## 4) التشغيل

```bash
npm start
```

عند التشغيل سيطبع البوت في السجل **رابط دعوة جاهز** بالصلاحيات الصحيحة، يبدأ بـ:
`https://discord.com/oauth2/authorize?client_id=...`

افتحه وأضف البوت لسيرفرك. إذا أردت بناء الرابط يدويًا فاستخدم `permissions=328768` و `scope=bot applications.commands`.

الصلاحيات التي يحتاجها البوت (مجرد 4):

| الصلاحية | سببها |
|---|---|
| View Channel | رؤية الروم |
| Read Message History | شرط من Discord لإضافة تفاعل جديد |
| Add Reactions | إضافة التفاعل |
| Use External Emojis | للإيموجي المخصص القادم من سيرفر آخر |

## 5) التشغيل 24/7 بـ PM2

```bash
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup        # نفّذ الأمر الذي يطبعه لك (Linux/macOS) ليعمل البوت بعد إعادة تشغيل السيرفر
```

أوامر مفيدة:

```bash
pm2 logs bot-reaction-free       # عرض السجلات
pm2 restart bot-reaction-free    # إعادة تشغيل
pm2 stop bot-reaction-free       # إيقاف
pm2 status                                    # الحالة
```

ملاحظات:

- لا ترفع `instances` عن 1، وإلا سيتفاعل أكثر من نسخة على نفس الرسالة.
- على Windows لا يدعم PM2 الأمر `pm2 startup`؛ استخدم Task Scheduler أو `pm2-installer`.

## الأوامر

| الأمر | الوصف |
|---|---|
| `/تفاعل` | إنشاء أو تعديل تفاعل. الخيارات: `الروم` + `الإيموجي` + `الحالة` (تشغيل/إيقاف، الافتراضي تشغيل) |
| `/تفاعل-حذف` | حذف التفاعل من روم |
| `/تفاعل-عرض` | عرض كل تفاعلات السيرفر وحالتها |
| `/تفاعل-إيقاف` | إيقاف مؤقت لروم محدد، أو لكل السيرفر إذا لم تحدد روم |
| `/تفاعل-تشغيل` | تشغيل روم محدد، أو كل السيرفر إذا لم تحدد روم |
| `/مالك-احصائيات` | (للمالك) إحصائيات البوت: السيرفرات، التفاعلات، الطابور، الذاكرة... |
| `/مالك-تنظيف` | (للمالك) حذف إعدادات سيرفرات خرج منها البوت ورومات محذوفة |

- أوامر الإدارة تتطلب صلاحية `Administrator`. ويتم التحقق منها مرة ثانية عند التنفيذ.
- مالك البوت (`OWNER_ID`) يستطيع تنفيذ أوامر الإدارة في أي سيرفر يوجد فيه البوت، ويحتكر أوامر `مالك-*`.
- الإيموجي المخصص يجب أن يكون من سيرفر موجود فيه البوت.
- التفاعل يعمل على رسائل الرومات النصية ورومات الإعلانات. رسائل الثريدات لها معرّف مختلف ولا تُحسب.

## كيف يعمل

- **Intents:** `Guilds` و `GuildMessages` و `GuildEmojisAndStickers` فقط. البوت لا يقرأ محتوى الرسائل أصلًا.
- **messageCreate:** يتجاهل البوتات والويبهوكات ورسائل النظام، ثم يتحقق من وجود تفاعل مفعّل للروم، ثم يضيف المهمة للطابور.
- **الطابور:** طابور مستقل لكل روم، بحد أقصى 200 مهمة. التفاعلات تُنفَّذ بالتسلسل وdiscord.js ينتظر الـ Rate Limits تلقائيًا.
- **الأخطاء:** رسالة محذوفة أو تفاعل محظور أو حد التفاعلات (20) يُتجاهل بهدوء. أخطاء الشبكة و5xx تُعاد محاولتها. نقص الصلاحيات يُسجَّل مرة كل 10 دقائق لكل روم ولا يسبب طلبات فاشلة. إذا صار الإيموجي غير صالح (مثلًا حُذف) يتوقف التفاعل في الروم تلقائيًا ويُسجَّل تحذير.
- **الاتصال:** discord.js يعيد الاتصال تلقائيًا. إذا بقي البوت غير جاهز أكثر من 5 دقائق أو أُبطلت الجلسة يخرج ليعيد PM2 تشغيله.
- **الأخطاء غير المتوقعة:** `unhandledRejection` يُسجَّل ويستمر البوت. `uncaughtException` يُسجَّل ثم يعيد PM2 التشغيل خلال ثوانٍ بحالة نظيفة.

## السجلات والبيانات

- `logs/combined-YYYY-MM-DD.log` كل الأحداث.
- `logs/error-YYYY-MM-DD.log` التحذيرات والأخطاء فقط (تُحذف الملفات الأقدم من 14 يومًا).
- `data/bot.sqlite` قاعدة البيانات. خذ نسخة احتياطية من مجلد `data/` دوريًا.

## هيكل المشروع

```text
bot-reaction-free/
├── src/
│   ├── index.js                 # نقطة التشغيل: العميل، الأحداث، تسجيل الدخول، الإغلاق الآمن
│   ├── config/                  # env, constants, paths
│   ├── commands/
│   │   ├── admin/               # setup, remove, list, pause, resume
│   │   └── owner/               # stats, cleanup
│   ├── events/                  # clientReady, messageCreate, interactionCreate, connection, ...
│   ├── services/                # reactionQueue, commandRegistrar, stats
│   ├── database/                # SQLite + migrations + repositories
│   └── utils/                   # logger, emoji, permissions, embeds, loader, ...
├── ecosystem.config.cjs         # إعدادات PM2
├── .env.example
└── package.json
```

## إضافة أمر أو حدث جديد

- **أمر:** أنشئ ملفًا داخل `src/commands/admin/` أو `src/commands/owner/` يصدّر `default { scope, data, execute }` وسيتم تحميله وتسجيله تلقائيًا.
- **حدث:** أنشئ ملفًا داخل `src/events/` يصدّر `default { name, once?, execute }` (أو مصفوفة منها).
- **جدول أو عمود:** أضف Migration جديدًا في نهاية المصفوفة داخل `src/database/index.js`.
- الملفات التي يبدأ اسمها بـ `_` يتم تجاهلها.

## استكشاف الأخطاء

| المشكلة | الحل |
|---|---|
| البوت يخرج فورًا برسالة عن `.env` | تأكد أن `.env` موجود في جذر المشروع وأن القيمتين صحيحتان |
| `Fatal login error` | التوكن غير صحيح. أعد توليده من Developer Portal |
| الأوامر لا تظهر | تأكد أنك دعوت البوت بنطاق `applications.commands`، وحدّث Discord بـ `Ctrl+R`، وراجع السجل بحثًا عن `Registered ... slash commands` |
| الأمر يظهر لكن لا أستطيع استخدامه | الأوامر للإدارة فقط (`Administrator`)، أو عدّل صلاحيات الأمر من إعدادات السيرفر ← Integrations |
| لا يتفاعل البوت | راجع الصلاحيات الأربع في الروم نفسه (قد تكون محجوبة بصلاحيات خاصة بالروم)، وتأكد أن الحالة `تشغيل` من `/تفاعل-عرض` |
| الإيموجي المخصص مرفوض | يجب أن يكون من سيرفر فيه البوت، ويُختار من قائمة الإيموجي أثناء كتابة الأمر |
| فشل تثبيت `better-sqlite3` | تأكد من Node 20+ وثبّت أدوات البناء (انظر المتطلبات) |
| PM2 يوقف البوت بعد محاولات متكررة | غالبًا مشكلة في `.env` أو التوكن. شغّل `npm start` لرؤية الخطأ |

## الأمان

- لا يوجد أي توكن أو بيانات حساسة داخل الكود. كل شيء في `.env` وهو مضاف إلى `.gitignore`.
- كذلك `data/` و `logs/` مستثناة من Git.
- إذا تسرب التوكن لأي سبب اضغط **Reset Token** فورًا من Developer Portal.

## الحقوق والترخيص

حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.

- المشروع مجاني بالكامل، **وغير قابل للبيع**: لا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
- يجب الإبقاء على إشعار حقوق الملكية في كل ملف وفي أي نسخة أو جزء من الكود.
- الرخصة: **PolyForm Noncommercial 1.0.0** (استخدام غير تجاري فقط). راجع [LICENSE.md](./LICENSE.md).
- المشروع مقدَّم "كما هو" بدون أي ضمانات، والمالك غير مسؤول عن أي أضرار أو فقدان بيانات أو ثغرات أو سوء استخدام. المستخدم هو المسؤول الوحيد عن استخدامه.

للتواصل: Discord: `iaf0` | GitHub: https://github.com/iiaf1
