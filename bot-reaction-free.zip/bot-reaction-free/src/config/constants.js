/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { ChannelType, PermissionFlagsBits, PermissionsBitField } from 'discord.js';

export const BOT_NAME = 'Bot Reaction Free';

// مستوى السجلات: debug | info | warn | error
export const LOG_LEVEL = 'info';
export const LOG_RETENTION_DAYS = 14;

// الصلاحية المطلوبة من المستخدم لاستخدام أوامر الإدارة
export const ADMIN_PERMISSION = PermissionFlagsBits.Administrator;

// أنواع الرومات المدعومة
export const SUPPORTED_CHANNEL_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement];

// أقل صلاحيات يحتاجها البوت في الروم (لا يحتاج Send Messages ولا أي صلاحية إدارية)
export const REQUIRED_BOT_PERMISSIONS = [
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.ReadMessageHistory,
  PermissionFlagsBits.AddReactions,
  PermissionFlagsBits.UseExternalEmojis,
];
export const INVITE_PERMISSIONS = new PermissionsBitField(REQUIRED_BOT_PERMISSIONS).bitfield.toString();

export const PERMISSION_LABELS = {
  ViewChannel: 'عرض الروم (View Channel)',
  ReadMessageHistory: 'قراءة سجل الرسائل (Read Message History)',
  AddReactions: 'إضافة التفاعلات (Add Reactions)',
  UseExternalEmojis: 'استخدام الإيموجي الخارجي (Use External Emojis)',
};

// طابور التفاعلات
export const QUEUE_MAX_PER_CHANNEL = 200;
export const REACT_MAX_RETRIES = 2;

// مراقبة الاتصال: إذا بقي البوت غير متصل أكثر من هذه المدة يتم إيقافه ليعيد PM2 تشغيله
export const WATCHDOG_INTERVAL_MS = 60_000;
export const WATCHDOG_MAX_DOWNTIME_MS = 5 * 60_000;

export const COLORS = {
  success: 0x57f287,
  error: 0xed4245,
  info: 0x5865f2,
  warning: 0xfee75c,
};
