/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import path from 'node:path';
import dotenv from 'dotenv';
import { ROOT_DIR } from './paths.js';

// يقرأ ملف .env من جذر المشروع بغض النظر عن مكان تشغيل الأمر
dotenv.config({ path: path.join(ROOT_DIR, '.env') });

const PLACEHOLDERS = new Set(['ضع_توكن_البوت_هنا', 'ضع_ايدي_الأونر_هنا']);

function readVar(name) {
  const value = process.env[name];
  return typeof value === 'string' ? value.trim() : '';
}

const DISCORD_TOKEN = readVar('DISCORD_TOKEN');
const OWNER_ID = readVar('OWNER_ID');

const problems = [];

if (!DISCORD_TOKEN || PLACEHOLDERS.has(DISCORD_TOKEN)) {
  problems.push('المتغير DISCORD_TOKEN غير موجود أو لم يتم تعديله. ضع توكن البوت في ملف .env');
}

if (!/^\d{17,20}$/.test(OWNER_ID)) {
  problems.push('المتغير OWNER_ID غير صحيح. يجب أن يكون ايدي حسابك (أرقام فقط) داخل ملف .env');
}

if (problems.length > 0) {
  console.error('\n[ENV] تعذر تشغيل البوت بسبب إعدادات .env:');
  for (const problem of problems) console.error(` - ${problem}`);
  console.error('\nانسخ .env.example إلى .env ثم عدّل القيم.\n');
  process.exit(1);
}

export const env = Object.freeze({ DISCORD_TOKEN, OWNER_ID });
