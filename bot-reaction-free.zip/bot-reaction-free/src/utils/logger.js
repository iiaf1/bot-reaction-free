/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import fs from 'node:fs';
import path from 'node:path';
import util from 'node:util';
import { LOGS_DIR } from '../config/paths.js';
import { LOG_LEVEL, LOG_RETENTION_DAYS } from '../config/constants.js';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const threshold = LEVELS[LOG_LEVEL] ?? LEVELS.info;

let lastPruneDay = null;

try {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
} catch {
  // إذا فشل إنشاء المجلد سنكتفي بالطباعة في الكونسول
}

function serialize(meta) {
  if (meta === undefined || meta === null) return '';
  if (meta instanceof Error) return `\n${util.inspect(meta, { depth: 4 })}`;
  if (typeof meta === 'object') return ` ${util.inspect(meta, { depth: 4, breakLength: Infinity })}`;
  return ` ${String(meta)}`;
}

function pruneOldLogs() {
  try {
    const cutoff = Date.now() - LOG_RETENTION_DAYS * 24 * 60 * 60 * 1000;
    for (const file of fs.readdirSync(LOGS_DIR)) {
      const match = /^(?:combined|error)-(\d{4}-\d{2}-\d{2})\.log$/.exec(file);
      if (!match) continue;
      if (Date.parse(`${match[1]}T00:00:00Z`) < cutoff) fs.unlinkSync(path.join(LOGS_DIR, file));
    }
  } catch {
    // تجاهل
  }
}

function write(level, message, meta) {
  if (LEVELS[level] < threshold) return;

  try {
    const now = new Date();
    const day = now.toISOString().slice(0, 10);
    const line = `${now.toISOString()} [${level.toUpperCase()}] ${message}${serialize(meta)}`;

    const out = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log;
    out(line);

    fs.appendFileSync(path.join(LOGS_DIR, `combined-${day}.log`), `${line}\n`);
    if (LEVELS[level] >= LEVELS.warn) {
      fs.appendFileSync(path.join(LOGS_DIR, `error-${day}.log`), `${line}\n`);
    }

    if (day !== lastPruneDay) {
      lastPruneDay = day;
      pruneOldLogs();
    }
  } catch {
    // المسجّل يجب ألا يتسبب أبدًا في إيقاف البوت
  }
}

export const logger = {
  debug: (message, meta) => write('debug', message, meta),
  info: (message, meta) => write('info', message, meta),
  warn: (message, meta) => write('warn', message, meta),
  error: (message, meta) => write('error', message, meta),
};
