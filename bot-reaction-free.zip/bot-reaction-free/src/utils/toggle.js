/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { errorEmbed, infoEmbed, successEmbed } from './embeds.js';
import { logger } from './logger.js';

/**
 * منطق مشترك لأمري الإيقاف والتشغيل.
 * إذا تم تحديد روم: يطبّق عليه فقط، وإلا يطبّق على كل تفاعلات السيرفر.
 */
export async function toggleReactions(interaction, ctx, enabled) {
  const { reactionRepo } = ctx;
  const channelOption = interaction.options.getChannel('الروم');
  const verb = enabled ? 'تشغيل' : 'إيقاف';

  if (channelOption) {
    const row = reactionRepo.get(channelOption.id);
    if (!row || row.guild_id !== interaction.guildId) {
      await interaction.editReply({
        embeds: [errorEmbed(`لا يوجد تفاعل محفوظ للروم <#${channelOption.id}>.\nاستخدم \`/تفاعل\` لإنشائه أولًا.`)],
      });
      return;
    }

    if (Boolean(row.enabled) === enabled) {
      await interaction.editReply({
        embeds: [infoEmbed(`التفاعل في <#${channelOption.id}> ${enabled ? 'يعمل' : 'متوقف'} بالفعل.`)],
      });
      return;
    }

    reactionRepo.setEnabled(channelOption.id, enabled, interaction.user.id);
    logger.info(`Reaction ${enabled ? 'enabled' : 'disabled'} in channel ${channelOption.id} (guild ${interaction.guildId}) by ${interaction.user.id}`);
    await interaction.editReply({
      embeds: [successEmbed(`تم ${verb} التفاعل في <#${channelOption.id}> ${row.emoji}`)],
    });
    return;
  }

  const changed = reactionRepo.setEnabledForGuild(interaction.guildId, enabled, interaction.user.id);
  if (changed === 0) {
    await interaction.editReply({
      embeds: [infoEmbed(`لا توجد تفاعلات تحتاج إلى ${verb} في هذا السيرفر.`)],
    });
    return;
  }

  logger.info(`Reactions ${enabled ? 'enabled' : 'disabled'} for ${changed} channel(s) in guild ${interaction.guildId} by ${interaction.user.id}`);
  await interaction.editReply({
    embeds: [successEmbed(`تم ${verb} ${changed} تفاعل في هذا السيرفر.`)],
  });
}
