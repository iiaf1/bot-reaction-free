/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { env } from '../config/env.js';
import { ADMIN_PERMISSION, PERMISSION_LABELS } from '../config/constants.js';

export function isOwner(userId) {
  return userId === env.OWNER_ID;
}

/** مالك البوت أو مستخدم لديه صلاحية Administrator داخل سيرفر */
export function isAdminInteraction(interaction) {
  if (isOwner(interaction.user.id)) return true;
  return interaction.inGuild() && Boolean(interaction.memberPermissions?.has(ADMIN_PERMISSION));
}

/** يرجع أسماء الصلاحيات الناقصة للبوت في الروم */
export function missingBotPermissions(channel, me, { external = false } = {}) {
  const permissions = channel.permissionsFor(me);
  const needed = ['ViewChannel', 'ReadMessageHistory', 'AddReactions'];
  if (external) needed.push('UseExternalEmojis');
  if (!permissions) return needed;
  return permissions.missing(needed);
}

export function labelPermissions(names) {
  return names.map((name) => PERMISSION_LABELS[name] ?? name);
}
