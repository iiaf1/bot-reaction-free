/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

// دعم الإيموجي العادي (Unicode) والمخصص (Custom Emoji)

const CUSTOM_EMOJI = /^<(a?):([A-Za-z0-9_]{2,32}):(\d{17,20})>$/;
const KEYCAP_EMOJI = /^([#*0-9])\uFE0F?\u20E3$/u;
const UNICODE_EMOJI =
  /^(?:\p{Regional_Indicator}{2}|\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?[\u{E0020}-\u{E007F}]*(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\p{Emoji_Modifier})?)*)$/u;

/**
 * يحلل مدخل المستخدم ويرجع كائنًا موحدًا أو null إذا لم يكن إيموجي صالحًا.
 *  - display:    الشكل المحفوظ في قاعدة البيانات والمعروض للمستخدم
 *  - identifier: القيمة التي تُمرّر إلى message.react()
 */
export function parseEmoji(input) {
  const value = String(input ?? '').trim();
  if (!value) return null;

  const custom = CUSTOM_EMOJI.exec(value);
  if (custom) {
    const [, animatedFlag, name, id] = custom;
    return {
      type: 'custom',
      animated: animatedFlag === 'a',
      name,
      id,
      display: value,
      identifier: `${name}:${id}`,
    };
  }

  const keycap = KEYCAP_EMOJI.exec(value);
  if (keycap) {
    const normalized = `${keycap[1]}\uFE0F\u20E3`;
    return { type: 'unicode', display: normalized, identifier: normalized };
  }

  if (UNICODE_EMOJI.test(value)) {
    return { type: 'unicode', display: value, identifier: value };
  }

  return null;
}
