/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { setTimeout as sleep } from 'node:timers/promises';
import { DiscordAPIError } from 'discord.js';
import { QUEUE_MAX_PER_CHANNEL, REACT_MAX_RETRIES } from '../config/constants.js';
import { parseEmoji } from '../utils/emoji.js';
import { labelPermissions, missingBotPermissions } from '../utils/permissions.js';
import { shouldLog } from '../utils/throttle.js';
import { logger } from '../utils/logger.js';
import { stats } from './stats.js';

// أخطاء Discord التي نتجاهلها بهدوء
const IGNORED_CODES = new Set([
  10003, // Unknown Channel
  10008, // Unknown Message (الرسالة حُذفت قبل التفاعل)
  30010, // Maximum number of reactions reached
  90001, // Reaction blocked
]);
const UNKNOWN_EMOJI = 10014;
const PERMISSION_CODES = new Set([50001, 50013]); // Missing Access / Missing Permissions

const TRANSIENT_NETWORK_CODES = new Set([
  'ECONNRESET',
  'ECONNREFUSED',
  'ETIMEDOUT',
  'EAI_AGAIN',
  'ENOTFOUND',
  'UND_ERR_SOCKET',
  'UND_ERR_CONNECT_TIMEOUT',
  'UND_ERR_HEADERS_TIMEOUT',
  'UND_ERR_BODY_TIMEOUT',
]);

function isTransient(error) {
  if (error instanceof DiscordAPIError) return error.status >= 500;
  return (
    error?.name === 'HTTPError' ||
    TRANSIENT_NETWORK_CODES.has(error?.code) ||
    TRANSIENT_NETWORK_CODES.has(error?.cause?.code)
  );
}

/**
 * طابور تفاعلات: طابور مستقل لكل روم، ينفّذ التفاعلات بالتسلسل.
 * discord.js يتولى انتظار الـ Rate Limits تلقائيًا، والطابور يمنع إغراق الـ API
 * ويحافظ على ترتيب الرسائل ويضع حدًا أقصى للذاكرة.
 */
export class ReactionQueue {
  #queues = new Map();

  constructor({ reactionRepo }) {
    this.repo = reactionRepo;
  }

  get pending() {
    let total = 0;
    for (const state of this.#queues.values()) total += state.jobs.length;
    return total;
  }

  enqueue(message) {
    const channelId = message.channelId;
    let state = this.#queues.get(channelId);
    if (!state) {
      state = { jobs: [], running: false };
      this.#queues.set(channelId, state);
    }

    if (state.jobs.length >= QUEUE_MAX_PER_CHANNEL) {
      stats.reactionsDropped++;
      if (shouldLog(`overflow:${channelId}`, 60_000)) {
        logger.warn(`Reaction queue is full for channel ${channelId}; dropping new messages until it drains.`);
      }
      return false;
    }

    state.jobs.push(message);
    if (!state.running) void this.#drain(channelId, state);
    return true;
  }

  async #drain(channelId, state) {
    state.running = true;
    try {
      while (state.jobs.length > 0) {
        const message = state.jobs.shift();
        try {
          await this.#process(message);
        } catch (error) {
          stats.reactionsFailed++;
          logger.error(`Unexpected error while processing a reaction job in channel ${channelId}`, error);
        }
      }
    } finally {
      state.running = false;
      if (state.jobs.length === 0) this.#queues.delete(channelId);
    }
  }

  async #process(message) {
    const channelId = message.channelId;

    // قد يكون الإعداد تغيّر أو أُوقف أثناء الانتظار في الطابور
    const row = this.repo.getActive(channelId);
    if (!row) return;

    const emoji = parseEmoji(row.emoji);
    if (!emoji) {
      if (shouldLog(`bad-emoji:${channelId}`)) {
        logger.warn(`Stored emoji "${row.emoji}" for channel ${channelId} is invalid; skipping.`);
      }
      return;
    }

    const guild = message.guild;
    const me = guild?.members.me ?? (await guild?.members.fetchMe().catch(() => null));
    if (!me) return;

    // فحص الصلاحيات قبل الإرسال لتجنب طلبات 403 كثيرة (تُحتسب كطلبات غير صالحة لدى Discord)
    const customEmoji = emoji.type === 'custom' ? message.client.emojis.cache.get(emoji.id) : null;
    const external = emoji.type === 'custom' && (!customEmoji || customEmoji.guild.id !== message.guildId);
    const missing = missingBotPermissions(message.channel, me, { external });
    if (missing.length > 0) {
      stats.reactionsSkipped++;
      if (shouldLog(`perm:${channelId}`)) {
        logger.warn(
          `Missing permissions in channel ${channelId} (guild ${message.guildId}): ${labelPermissions(missing).join(', ')}`,
        );
      }
      return;
    }

    await this.#reactWithRetry(message, emoji);
  }

  async #reactWithRetry(message, emoji) {
    for (let attempt = 0; attempt <= REACT_MAX_RETRIES; attempt++) {
      try {
        await message.react(emoji.identifier);
        stats.reactionsAdded++;
        return;
      } catch (error) {
        if (isTransient(error) && attempt < REACT_MAX_RETRIES) {
          await sleep(1000 * 2 ** attempt);
          continue;
        }
        this.#handleError(error, message, emoji);
        return;
      }
    }
  }

  #handleError(error, message, emoji) {
    const channelId = message.channelId;
    const code = error instanceof DiscordAPIError ? error.code : undefined;

    if (IGNORED_CODES.has(code)) {
      logger.debug(`Ignored Discord error ${code} while reacting in channel ${channelId}`);
      return;
    }

    stats.reactionsFailed++;

    if (code === UNKNOWN_EMOJI) {
      this.repo.setEnabled(channelId, false, 'system');
      logger.warn(
        `Emoji ${emoji.display} is not usable (Unknown Emoji). Auto-reaction was disabled for channel ${channelId} (guild ${message.guildId}).`,
      );
      return;
    }

    if (PERMISSION_CODES.has(code)) {
      if (shouldLog(`perm-api:${channelId}`)) {
        logger.warn(`Discord denied the reaction in channel ${channelId} (guild ${message.guildId}), code ${code}: ${error.message}`);
      }
      return;
    }

    logger.error(`Failed to add reaction in channel ${channelId} (guild ${message.guildId})`, error);
  }
}
