/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import crypto from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';
import { logger } from '../utils/logger.js';

/**
 * يسجّل أوامر السلاش بشكل عام (Global) دون الحاجة إلى CLIENT_ID أو GUILD_ID.
 * معرّف التطبيق يُؤخذ تلقائيًا من client.application.id بعد تسجيل الدخول.
 * لا يعيد التسجيل إذا كانت الأوامر لم تتغير (لتجنب الضغط على Discord API).
 */
export async function registerCommands({ client, metaRepo, commands }) {
  const body = commands.map((command) => command.data.toJSON());
  const hash = crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
  const metaKey = `commands_hash:${client.application.id}`;

  try {
    const registered = await client.application.commands.fetch();
    const sameNames =
      registered.size === body.length && body.every((command) => registered.some((r) => r.name === command.name));

    if (sameNames && metaRepo.get(metaKey) === hash) {
      logger.info(`Slash commands are up to date (${body.length}); skipping registration.`);
      return;
    }
  } catch (error) {
    logger.warn('Could not fetch registered commands; will try to register them anyway.', error);
  }

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      await client.application.commands.set(body);
      metaRepo.set(metaKey, hash);
      logger.info(`Registered ${body.length} global slash commands.`);
      return;
    } catch (error) {
      logger.error(`Failed to register slash commands (attempt ${attempt}/3)`, error);
      if (attempt < 3) await sleep(5000 * attempt);
    }
  }

  logger.error('Could not register slash commands. The bot keeps running with the previously registered commands.');
}
