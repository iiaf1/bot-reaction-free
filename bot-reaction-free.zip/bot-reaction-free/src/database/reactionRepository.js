/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

export function createReactionRepository(db) {
  const statements = {
    upsert: db.prepare(`
      INSERT INTO channel_reactions
        (channel_id, guild_id, emoji, enabled, created_by, updated_by, created_at, updated_at)
      VALUES
        (@channelId, @guildId, @emoji, @enabled, @userId, @userId, @now, @now)
      ON CONFLICT(channel_id) DO UPDATE SET
        guild_id   = excluded.guild_id,
        emoji      = excluded.emoji,
        enabled    = excluded.enabled,
        updated_by = excluded.updated_by,
        updated_at = excluded.updated_at
    `),
    get: db.prepare('SELECT * FROM channel_reactions WHERE channel_id = ?'),
    getActive: db.prepare('SELECT emoji FROM channel_reactions WHERE channel_id = ? AND enabled = 1'),
    listByGuild: db.prepare('SELECT * FROM channel_reactions WHERE guild_id = ? ORDER BY created_at ASC'),
    listGuildIds: db.prepare('SELECT DISTINCT guild_id FROM channel_reactions'),
    delete: db.prepare('DELETE FROM channel_reactions WHERE channel_id = ?'),
    deleteByGuild: db.prepare('DELETE FROM channel_reactions WHERE guild_id = ?'),
    setEnabled: db.prepare(`
      UPDATE channel_reactions
      SET enabled = @enabled, updated_by = @userId, updated_at = @now
      WHERE channel_id = @channelId
    `),
    setEnabledForGuild: db.prepare(`
      UPDATE channel_reactions
      SET enabled = @enabled, updated_by = @userId, updated_at = @now
      WHERE guild_id = @guildId AND enabled != @enabled
    `),
    counts: db.prepare('SELECT COUNT(*) AS total, COALESCE(SUM(enabled), 0) AS active FROM channel_reactions'),
  };

  return {
    upsert({ channelId, guildId, emoji, enabled, userId }) {
      statements.upsert.run({
        channelId,
        guildId,
        emoji,
        enabled: enabled ? 1 : 0,
        userId,
        now: Date.now(),
      });
    },

    get(channelId) {
      return statements.get.get(channelId);
    },

    /** يرجع الإعداد فقط إذا كان مفعّلًا (يُستخدم في messageCreate) */
    getActive(channelId) {
      return statements.getActive.get(channelId);
    },

    listByGuild(guildId) {
      return statements.listByGuild.all(guildId);
    },

    listGuildIds() {
      return statements.listGuildIds.all().map((row) => row.guild_id);
    },

    delete(channelId) {
      return statements.delete.run(channelId).changes;
    },

    deleteByGuild(guildId) {
      return statements.deleteByGuild.run(guildId).changes;
    },

    setEnabled(channelId, enabled, userId) {
      return statements.setEnabled.run({
        channelId,
        enabled: enabled ? 1 : 0,
        userId,
        now: Date.now(),
      }).changes;
    },

    setEnabledForGuild(guildId, enabled, userId) {
      return statements.setEnabledForGuild.run({
        guildId,
        enabled: enabled ? 1 : 0,
        userId,
        now: Date.now(),
      }).changes;
    },

    counts() {
      const row = statements.counts.get();
      return { total: row.total, active: row.active };
    },
  };
}
