/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { Events, MessageFlags } from 'discord.js';
import { stats } from '../services/stats.js';
import { errorEmbed } from '../utils/embeds.js';
import { isAdminInteraction, isOwner } from '../utils/permissions.js';
import { logger } from '../utils/logger.js';

async function safeReply(interaction, embed) {
  try {
    if (interaction.replied) {
      await interaction.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral });
    } else if (interaction.deferred) {
      await interaction.editReply({ embeds: [embed] });
    } else {
      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  } catch (error) {
    logger.warn('Failed to send an interaction reply', error);
  }
}

export default {
  name: Events.InteractionCreate,

  async execute(ctx, interaction) {
    if (!interaction.isChatInputCommand()) return;

    const command = ctx.commands.get(interaction.commandName);
    if (!command) {
      await safeReply(interaction, errorEmbed('هذا الأمر غير معروف أو لم يعد متاحًا.'));
      return;
    }

    // فحص الصلاحيات في وقت التنفيذ (حتى لو غيّر أحد إعدادات الأمر من إعدادات السيرفر)
    if (command.scope === 'owner' && !isOwner(interaction.user.id)) {
      await safeReply(interaction, errorEmbed('هذا الأمر لمالك البوت فقط.'));
      return;
    }

    if (command.scope === 'admin' && !isAdminInteraction(interaction)) {
      await safeReply(interaction, errorEmbed('هذا الأمر للإدارة فقط (صلاحية Administrator).'));
      return;
    }

    try {
      stats.commandsRun++;
      await command.execute(interaction, ctx);
    } catch (error) {
      // 10062 = Unknown interaction, 40060 = already acknowledged
      if (error?.code === 10062 || error?.code === 40060) {
        logger.warn(`Interaction /${interaction.commandName} expired or was already acknowledged (code ${error.code}).`);
        return;
      }

      logger.error(`Command /${interaction.commandName} failed`, error);
      await safeReply(interaction, errorEmbed('حدث خطأ غير متوقع أثناء تنفيذ الأمر. حاول مرة أخرى بعد قليل.'));
    }
  },
};
