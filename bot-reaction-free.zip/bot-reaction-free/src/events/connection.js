/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { Events } from 'discord.js';
import { logger } from '../utils/logger.js';

// تسجيل أحداث الاتصال. إعادة الاتصال نفسها يتولاها discord.js تلقائيًا (Resume / Reconnect).
export default [
  {
    name: Events.Error,
    execute: (ctx, error) => logger.error('Discord client error', error),
  },
  {
    name: Events.Warn,
    execute: (ctx, info) => logger.warn(`Discord client warning: ${info}`),
  },
  {
    name: Events.ShardReady,
    execute: (ctx, shardId, unavailableGuilds) =>
      logger.info(`Shard ${shardId} ready${unavailableGuilds?.size ? ` (${unavailableGuilds.size} unavailable guilds)` : ''}`),
  },
  {
    name: Events.ShardDisconnect,
    execute: (ctx, closeEvent, shardId) =>
      logger.warn(`Shard ${shardId} disconnected (code ${closeEvent?.code ?? 'unknown'}). Reconnecting automatically...`),
  },
  {
    name: Events.ShardReconnecting,
    execute: (ctx, shardId) => logger.info(`Shard ${shardId} is reconnecting...`),
  },
  {
    name: Events.ShardResume,
    execute: (ctx, shardId, replayedEvents) => logger.info(`Shard ${shardId} resumed (${replayedEvents} events replayed).`),
  },
  {
    name: Events.ShardError,
    execute: (ctx, error, shardId) => logger.error(`Shard ${shardId} error`, error),
  },
  {
    name: Events.Invalidated,
    execute: async (ctx) => {
      logger.error('Discord session was invalidated. Exiting so PM2 can restart the bot.');
      await ctx.shutdown(1);
    },
  },
];
