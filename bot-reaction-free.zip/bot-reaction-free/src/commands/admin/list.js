/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { EmbedBuilder, InteractionContextType, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { ADMIN_PERMISSION, COLORS } from '../../config/constants.js';
import { chunkLines, infoEmbed } from '../../utils/embeds.js';

export default {
  scope: 'admin',

  data: new SlashCommandBuilder()
    .setName('تفاعل-عرض')
    .setDescription('عرض كل التفاعلات المحفوظة في هذا السيرفر')
    .setDefaultMemberPermissions(ADMIN_PERMISSION)
    .setContexts(InteractionContextType.Guild),

  async execute(interaction, ctx) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const rows = ctx.reactionRepo.listByGuild(interaction.guildId);
    if (rows.length === 0) {
      await interaction.editReply({
        embeds: [infoEmbed('لا توجد تفاعلات محفوظة في هذا السيرفر.\nاستخدم `/تفاعل` لإنشاء أول تفاعل.', '📭 لا يوجد شيء')],
      });
      return;
    }

    const active = rows.filter((row) => row.enabled).length;
    const lines = rows.map(
      (row, index) => `${index + 1}. <#${row.channel_id}> — ${row.emoji} — ${row.enabled ? '🟢 يعمل' : '🔴 متوقف'}`,
    );
    const chunks = chunkLines(lines);

    for (let i = 0; i < chunks.length; i++) {
      const embed = new EmbedBuilder()
        .setColor(COLORS.info)
        .setTitle(i === 0 ? '📋 التفاعلات الحالية' : '📋 التفاعلات الحالية (تابع)')
        .setDescription(chunks[i]);

      if (i === chunks.length - 1) {
        embed.setFooter({ text: `الإجمالي: ${rows.length} | يعمل: ${active} | متوقف: ${rows.length - active}` });
      }

      if (i === 0) {
        await interaction.editReply({ embeds: [embed] });
      } else {
        await interaction.followUp({ embeds: [embed], flags: MessageFlags.Ephemeral });
      }
    }
  },
};
