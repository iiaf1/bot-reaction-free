/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { InteractionContextType, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { ADMIN_PERMISSION, SUPPORTED_CHANNEL_TYPES } from '../../config/constants.js';
import { parseEmoji } from '../../utils/emoji.js';
import { labelPermissions, missingBotPermissions } from '../../utils/permissions.js';
import { errorEmbed, successEmbed } from '../../utils/embeds.js';
import { logger } from '../../utils/logger.js';

export default {
  scope: 'admin',

  data: new SlashCommandBuilder()
    .setName('تفاعل')
    .setDescription('إنشاء أو تعديل تفاعل تلقائي (إيموجي) على رسائل روم محدد')
    .setDefaultMemberPermissions(ADMIN_PERMISSION)
    .setContexts(InteractionContextType.Guild)
    .addChannelOption((option) =>
      option
        .setName('الروم')
        .setDescription('الروم الذي سيتم التفاعل على رسائله')
        .addChannelTypes(...SUPPORTED_CHANNEL_TYPES)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName('الإيموجي')
        .setDescription('إيموجي عادي أو مخصص (من سيرفر البوت موجود فيه)')
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName('الحالة')
        .setDescription('تشغيل أو إيقاف (الافتراضي: تشغيل)')
        .addChoices({ name: 'تشغيل', value: 'on' }, { name: 'إيقاف', value: 'off' }),
    ),

  async execute(interaction, ctx) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const channelOption = interaction.options.getChannel('الروم', true);
    const emojiInput = interaction.options.getString('الإيموجي', true);
    const enabled = (interaction.options.getString('الحالة') ?? 'on') === 'on';

    const emoji = parseEmoji(emojiInput);
    if (!emoji) {
      await interaction.editReply({
        embeds: [
          errorEmbed(
            'الإيموجي غير صالح.\nأرسل إيموجي واحدًا فقط، إما عاديًا مثل 🔥 أو مخصصًا مثل `<:name:123456789012345678>` (اختره من قائمة الإيموجي أثناء كتابة الأمر).',
          ),
        ],
      });
      return;
    }

    let customEmoji = null;
    if (emoji.type === 'custom') {
      customEmoji = interaction.client.emojis.cache.get(emoji.id) ?? null;
      if (!customEmoji || customEmoji.available === false) {
        await interaction.editReply({
          embeds: [
            errorEmbed(
              'لا يستطيع البوت استخدام هذا الإيموجي المخصص.\nيجب أن يكون الإيموجي من سيرفر البوت موجود فيه، وأن يكون متاحًا (غير محذوف أو مقفل).',
            ),
          ],
        });
        return;
      }
    }

    const guild = interaction.guild ?? (await interaction.client.guilds.fetch(interaction.guildId));
    const channel =
      guild.channels.cache.get(channelOption.id) ?? (await guild.channels.fetch(channelOption.id).catch(() => null));
    if (!channel) {
      await interaction.editReply({ embeds: [errorEmbed('تعذر العثور على هذا الروم.')] });
      return;
    }

    const me = guild.members.me ?? (await guild.members.fetchMe());
    const external = emoji.type === 'custom' && customEmoji?.guild.id !== guild.id;
    const missing = missingBotPermissions(channel, me, { external });

    const existed = Boolean(ctx.reactionRepo.get(channel.id));
    ctx.reactionRepo.upsert({
      channelId: channel.id,
      guildId: guild.id,
      emoji: emoji.display,
      enabled,
      userId: interaction.user.id,
    });

    logger.info(
      `Reaction ${existed ? 'updated' : 'created'}: channel ${channel.id} (guild ${guild.id}) emoji ${emoji.display} enabled=${enabled} by ${interaction.user.id}`,
    );

    const embed = successEmbed(
      existed ? 'تم تعديل إعداد التفاعل لهذا الروم.' : 'تم إنشاء إعداد التفاعل لهذا الروم.',
      existed ? '✅ تم التعديل' : '✅ تم الإنشاء',
    ).addFields(
      { name: 'الروم', value: `<#${channel.id}>`, inline: true },
      { name: 'الإيموجي', value: emoji.display, inline: true },
      { name: 'الحالة', value: enabled ? '🟢 يعمل' : '🔴 متوقف', inline: true },
    );

    if (missing.length > 0) {
      embed.addFields({
        name: '⚠️ تنبيه: صلاحيات ناقصة',
        value: `البوت ينقصه في <#${channel.id}>:\n${labelPermissions(missing)
          .map((label) => `• ${label}`)
          .join('\n')}\nلن يتفاعل البوت قبل منحه هذه الصلاحيات.`,
      });
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
