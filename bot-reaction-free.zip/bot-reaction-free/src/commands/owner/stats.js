/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { EmbedBuilder, InteractionContextType, MessageFlags, SlashCommandBuilder, version as discordJsVersion } from 'discord.js';
import { BOT_NAME, COLORS } from '../../config/constants.js';
import { stats } from '../../services/stats.js';
import { formatDuration } from '../../utils/format.js';

export default {
  scope: 'owner',

  data: new SlashCommandBuilder()
    .setName('مالك-احصائيات')
    .setDescription('إحصائيات البوت (لمالك البوت فقط)')
    .setDefaultMemberPermissions(0)
    .setContexts(InteractionContextType.Guild, InteractionContextType.BotDM),

  async execute(interaction, ctx) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const { client } = interaction;
    const counts = ctx.reactionRepo.counts();
    const members = client.guilds.cache.reduce((total, guild) => total + (guild.memberCount ?? 0), 0);
    const memoryMb = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);

    const embed = new EmbedBuilder()
      .setColor(COLORS.info)
      .setTitle(`📊 ${BOT_NAME}`)
      .addFields(
        { name: 'السيرفرات', value: String(client.guilds.cache.size), inline: true },
        { name: 'الأعضاء (تقريبًا)', value: String(members), inline: true },
        { name: 'Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: 'التفاعلات المحفوظة', value: `${counts.total} (يعمل: ${counts.active})`, inline: true },
        { name: 'في الطابور الآن', value: String(ctx.reactionQueue.pending), inline: true },
        { name: 'الأوامر المنفذة', value: String(stats.commandsRun), inline: true },
        { name: 'تفاعلات أُضيفت', value: String(stats.reactionsAdded), inline: true },
        { name: 'تفاعلات فشلت', value: String(stats.reactionsFailed), inline: true },
        { name: 'تفاعلات تم تخطيها/إسقاطها', value: `${stats.reactionsSkipped} / ${stats.reactionsDropped}`, inline: true },
        { name: 'مدة التشغيل', value: formatDuration(Date.now() - stats.startedAt), inline: true },
        { name: 'الذاكرة', value: `${memoryMb} MB`, inline: true },
        { name: 'الإصدارات', value: `Node ${process.version} | discord.js ${discordJsVersion}`, inline: true },
      )
      .setFooter({ text: 'العدادات تُصفَّر عند إعادة تشغيل البوت' });

    await interaction.editReply({ embeds: [embed] });
  },
};
