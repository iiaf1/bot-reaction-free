/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import { InteractionContextType, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { errorEmbed, successEmbed } from '../../utils/embeds.js';
import { logger } from '../../utils/logger.js';

export default {
  scope: 'owner',

  data: new SlashCommandBuilder()
    .setName('مالك-تنظيف')
    .setDescription('حذف إعدادات السيرفرات التي خرج منها البوت والرومات المحذوفة (لمالك البوت فقط)')
    .setDefaultMemberPermissions(0)
    .setContexts(InteractionContextType.Guild, InteractionContextType.BotDM),

  async execute(interaction, ctx) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const { client } = interaction;
    if (client.guilds.cache.size === 0) {
      await interaction.editReply({
        embeds: [errorEmbed('قائمة السيرفرات فارغة حاليًا، تم إلغاء التنظيف لأسباب أمان.')],
      });
      return;
    }

    let orphanGuilds = 0;
    let removedRows = 0;

    for (const guildId of ctx.reactionRepo.listGuildIds()) {
      const guild = client.guilds.cache.get(guildId);

      if (!guild) {
        removedRows += ctx.reactionRepo.deleteByGuild(guildId);
        orphanGuilds++;
        continue;
      }

      if (!guild.available) continue;

      for (const row of ctx.reactionRepo.listByGuild(guildId)) {
        if (!guild.channels.cache.has(row.channel_id)) {
          removedRows += ctx.reactionRepo.delete(row.channel_id);
        }
      }
    }

    logger.info(`Owner cleanup by ${interaction.user.id}: removed ${removedRows} row(s), ${orphanGuilds} orphan guild(s).`);

    await interaction.editReply({
      embeds: [
        successEmbed(
          `تم حذف **${removedRows}** إعداد.\nسيرفرات غير موجودة: **${orphanGuilds}**`,
          '🧹 تم التنظيف',
        ),
      ],
    });
  },
};
