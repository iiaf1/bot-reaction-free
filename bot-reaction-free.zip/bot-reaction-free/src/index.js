/**
 * ============================================================
 *  Bot Reaction Free
 *  حقوق الملكية © 2026 iaf1 — جميع الحقوق محفوظة.
 *  Copyright © 2026 iaf1 — All rights reserved.
 * ============================================================
 *
 * [AR] إشعار المشروع:
 *  - هذا المشروع مجاني بالكامل.
 *  - هذا المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
 *  - يجب الإبقاء على إشعار حقوق الملكية هذا في أي نسخة أو جزء من الكود.
 *  - الرخصة: PolyForm Noncommercial 1.0.0 (استخدام غير تجاري فقط) — راجع LICENSE.md.
 *
 * [AR] إخلاء المسؤولية:
 *  هذا الملف مقدَّم "كما هو" (AS IS) بدون أي ضمانات من أي نوع.
 *  المالك (iaf1) غير مسؤول عن أي أضرار أو خسائر أو مشاكل في السيرفر
 *  أو فقدان بيانات أو ثغرات أمنية أو سوء استخدام ناتج عن استخدام هذا الكود
 *  أو تعديله أو استضافته. المستخدم هو المسؤول الوحيد عن استخدامه.
 *
 * [EN] Project Notice:
 *  - This project is completely free.
 *  - This project is NOT for sale. Selling it, its source code, or any
 *    modified version of it is not permitted by the owner.
 *  - This copyright notice must be retained in all copies and derivatives.
 *  - License: PolyForm Noncommercial 1.0.0 (noncommercial use only) — see LICENSE.md.
 *
 * [EN] Disclaimer:
 *  This file is provided "AS IS", without warranty of any kind. The owner
 *  (iaf1) is not liable for any damage, loss, server issues, data loss,
 *  security issues, or misuse resulting from the use, modification, or
 *  hosting of this code. The user is solely responsible for its use.
 *
 * Contact / للتواصل:
 *  Discord: iaf0
 *  GitHub:  https://github.com/iiaf1
 */

import path from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { Client, GatewayIntentBits, Options, Status } from 'discord.js';

// يجب أن يكون env أول استيراد: يتحقق من .env ويوقف التشغيل برسالة واضحة عند وجود خطأ
import { env } from './config/env.js';
import { BOT_NAME, WATCHDOG_INTERVAL_MS, WATCHDOG_MAX_DOWNTIME_MS } from './config/constants.js';
import { SRC_DIR } from './config/paths.js';
import { openDatabase } from './database/index.js';
import { createMetaRepository } from './database/metaRepository.js';
import { createReactionRepository } from './database/reactionRepository.js';
import { ReactionQueue } from './services/reactionQueue.js';
import { importModules } from './utils/loader.js';
import { logger } from './utils/logger.js';
import { shouldLog } from './utils/throttle.js';

const COMMANDS_DIR = path.join(SRC_DIR, 'commands');
const EVENTS_DIR = path.join(SRC_DIR, 'events');

// أخطاء تسجيل الدخول التي لا فائدة من إعادة المحاولة معها
const FATAL_LOGIN_CODES = new Set(['TokenInvalid', 'TokenMissing', 'DisallowedIntents', 'InvalidIntents']);

let client = null;
let db = null;
let shuttingDown = false;

async function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info(`Shutting down (exit code ${code})...`);

  const forceExit = setTimeout(() => process.exit(code), 8000);
  forceExit.unref();

  try {
    await client?.destroy();
  } catch (error) {
    logger.error('Error while destroying the Discord client', error);
  }

  try {
    db?.close();
  } catch (error) {
    logger.error('Error while closing the database', error);
  }

  process.exit(code);
}

process.on('SIGINT', () => void shutdown(0));
process.on('SIGTERM', () => void shutdown(0));

// أخطاء Promise غير المعالجة: نسجلها ونكمل التشغيل
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', reason);
});

// خطأ غير متوقع على مستوى العملية: نسجله ثم نخرج ليعيد PM2 التشغيل فورًا بحالة نظيفة
process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception', error);
  void shutdown(1);
});

async function loadCommands() {
  const commands = new Map();
  for (const { file, value } of await importModules(COMMANDS_DIR)) {
    const valid =
      value?.data?.name && typeof value.execute === 'function' && ['admin', 'owner'].includes(value.scope);
    if (!valid) {
      logger.warn(`Skipping invalid command module: ${path.basename(file)}`);
      continue;
    }
    if (commands.has(value.data.name)) {
      logger.warn(`Skipping duplicate command name "${value.data.name}" in ${path.basename(file)}`);
      continue;
    }
    commands.set(value.data.name, value);
  }
  return commands;
}

async function loadEvents() {
  const events = [];
  for (const { file, value } of await importModules(EVENTS_DIR)) {
    for (const event of Array.isArray(value) ? value : [value]) {
      if (!event?.name || typeof event.execute !== 'function') {
        logger.warn(`Skipping invalid event module: ${path.basename(file)}`);
        continue;
      }
      events.push(event);
    }
  }
  return events;
}

function registerEvents(events, ctx) {
  for (const event of events) {
    const handler = async (...args) => {
      try {
        await event.execute(ctx, ...args);
      } catch (error) {
        logger.error(`Unhandled error in event "${event.name}"`, error);
      }
    };
    if (event.once) client.once(event.name, handler);
    else client.on(event.name, handler);
  }
}

async function loginWithRetry(token) {
  let delay = 5_000;
  for (;;) {
    try {
      await client.login(token);
      return;
    } catch (error) {
      if (FATAL_LOGIN_CODES.has(error?.code)) {
        logger.error('Fatal login error. Check DISCORD_TOKEN in .env (and that no privileged intents are required).', error);
        await shutdown(1);
        return;
      }
      logger.error(`Login failed. Retrying in ${delay / 1000}s...`, error);
      await sleep(delay);
      delay = Math.min(delay * 2, 60_000);
    }
  }
}

// إذا بقي البوت غير متصل لفترة طويلة نخرج ليعيد PM2 تشغيله
function startWatchdog() {
  let offlineSince = null;
  setInterval(() => {
    if (client.ws.status === Status.Ready) {
      offlineSince = null;
      return;
    }
    offlineSince ??= Date.now();
    if (Date.now() - offlineSince > WATCHDOG_MAX_DOWNTIME_MS) {
      logger.error(`Gateway has not been ready for more than ${WATCHDOG_MAX_DOWNTIME_MS / 60_000} minutes. Restarting...`);
      void shutdown(1);
    }
  }, WATCHDOG_INTERVAL_MS).unref();
}

async function main() {
  logger.info(`Starting ${BOT_NAME}...`);

  db = openDatabase();
  const reactionRepo = createReactionRepository(db);
  const metaRepo = createMetaRepository(db);

  client = new Client({
    // أقل Intents ممكنة: لا نحتاج Message Content ولا أي Privileged Intent
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildEmojisAndStickers],
    allowedMentions: { parse: [], repliedUser: false },
    // نقلل الذاكرة: لا نحتاج تخزين الرسائل أو التفاعلات أو الحضور
    makeCache: Options.cacheWithLimits({
      ...Options.DefaultMakeCacheSettings,
      MessageManager: 0,
      ReactionManager: 0,
      ReactionUserManager: 0,
      PresenceManager: 0,
      VoiceStateManager: 0,
    }),
  });

  // discord.js يعالج الـ Rate Limits وينتظر تلقائيًا؛ نسجلها فقط (مع تقليل التكرار)
  client.rest.on('rateLimited', (info) => {
    if (shouldLog(`ratelimit:${info.route}`, 30_000)) {
      logger.warn(`Rate limited: ${info.method} ${info.route} - retry in ${info.timeToReset}ms (global: ${info.global})`);
    }
  });

  const commands = await loadCommands();
  const events = await loadEvents();
  logger.info(`Loaded ${commands.size} command(s) and ${events.length} event handler(s).`);

  const ctx = {
    client,
    db,
    reactionRepo,
    metaRepo,
    reactionQueue: new ReactionQueue({ reactionRepo }),
    commands,
    shutdown,
  };

  registerEvents(events, ctx);

  await loginWithRetry(env.DISCORD_TOKEN);
  startWatchdog();
}

main().catch((error) => {
  logger.error('Fatal startup error', error);
  void shutdown(1);
});
